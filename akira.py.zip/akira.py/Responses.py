from datetime import datetime

def sample_responses(input_text):
    user_message = str(input_text).lower()

    if user_message in ("hello", "hi", "sup",):
        return "Hey!Are you want to make an order? If it is true please continue"

    if user_message in ("", "hi", "sup",):
        return "Hey!How's it going?"