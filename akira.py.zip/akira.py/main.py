import telebot

bot = telebot.Telebot("1814182537:AAHkDB-UuRVIapc6GYQjjFH0it2r2LAz8Hs")


user_data = {}

class User:
    def __init__(self, first_name):
        self.first_name = first_name
        self.last_name = ''
@bot.message_handler(commands='start', 'help'])
def send_welcome(message):
       msg = bot.send_message(message.chat.id, "Введите имя")
       bot.register_next_step_handler(msg, process_firstname_step)

def process_firstname_step(message):
    try:
        user_id = message.from_user.id
        user_data[user_id] = User(message.text)

        msg = bot.send_message(message.chat.id, "Введите фамилию")
        bot.register_next_step_handler(msg, process_lastname_step)
    except Exception as e:
        bot.reply_to(message, 'oooops')
bot.enable_save_next_step_handlers(delay=2)
bot.load_next_step_handlers()

if __name__ == '__main__':
    bot.polling(none_stop=True)